const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./preschool.db');

db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS children (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        age INTEGER,
        level INTEGER DEFAULT 1,
        stars INTEGER DEFAULT 0,
        last_activity TEXT
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS progress (
        child_id INTEGER,
        category TEXT,
        points INTEGER,
        FOREIGN KEY (child_id) REFERENCES children(id)
    )`);
});

exports.getAllChildren = () => new Promise((resolve) => {
    db.all('SELECT * FROM children', [], (err, rows) => resolve(rows || []));
});

exports.registerChild = (name, age) => new Promise((resolve) => {
    db.run('INSERT INTO children (name, age, last_activity) VALUES (?, ?, datetime("now"))', [name, age], function () {
        resolve(this.lastID);
    });
});

exports.getChildProfile = (id) => new Promise((resolve) => {
    db.get('SELECT * FROM children WHERE id = ?', [id], (err, child) => {
        if (!child) return resolve(null);
        db.all('SELECT category, points FROM progress WHERE child_id = ?', [id], (err, progress) => {
            const profile = {
                ...child,
                progress: { math: 0, reading: 0, logic: 0, memory: 0 }
            };
            progress.forEach(row => profile.progress[row.category] = row.points);
            resolve(profile);
        });
    });
});

exports.updateProgress = (id, category, points) => new Promise((resolve) => {
    db.run('DELETE FROM progress WHERE child_id = ? AND category = ?', [id, category], () => {
        db.run('INSERT INTO progress (child_id, category, points) VALUES (?, ?, ?)', [id, category, points], () => {
            db.get('SELECT SUM(points) as total FROM progress WHERE child_id = ?', [id], (err, row) => {
                const level = 1 + Math.floor((row.total || 0) / 100);
                db.run('UPDATE children SET level = ?, stars = ?, last_activity = datetime("now") WHERE id = ?', [level, row.total, id], resolve);
            });
        });
    });
});