exports.generateTask = (category, level) => {
    const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
    if (category === 'math') {
        const a = rand(1, level < 3 ? 5 : 10);
        const b = rand(1, level < 3 ? 5 : 10);
        const op = level < 3 ? '+' : ['+', '-'][rand(0, 1)];
        const result = op === '+' ? a + b : a - b;
        return { question: `Сколько будет ${a} ${op} ${b}?`, answer: String(result) };
    } else if (category === 'reading') {
        const words = {
            1: ['кот', 'дом', 'сад', 'мяч'],
            2: ['мама', 'папа', 'река', 'луна'],
            3: ['солнце', 'машина', 'дерево', 'цветок']
        };
        const word = words[Math.min(level, 3)][rand(0, 3)];
        return { question: `Прочитай слово: ${word}`, answer: word };
    } else if (category === 'logic') {
        if (level < 3) {
            const sequence = ['1', '2', '3'];
            const seq = Array.from({ length: 3 }, () => sequence[rand(0, 2)]);
            return { question: `Продолжи последовательность: ${seq.join(' ')} ?`, answer: sequence[rand(0, 2)] };
        } else {
            const colors = ['красный', 'синий', 'зеленый'];
            const objects = ['яблоко', 'шарик', 'кубик'];
            const color = colors[rand(0, 2)];
            const obj = objects[rand(0, 2)];
            return { question: `Какого цвета ${obj} обычно бывает?`, answer: color };
        }
    }
    return { question: 'Задание не найдено', answer: '' };
};