const express = require('express');
const router = express.Router();
const db = require('../models/db');
const logic = require('../models/logic');

router.get('/', async (req, res) => {
    const children = await db.getAllChildren();
    res.render('index', { children });
});

router.post('/register', async (req, res) => {
    const { name, age } = req.body;
    if (age < 5 || age > 7) return res.send('Возраст должен быть от 5 до 7 лет.');
    await db.registerChild(name, parseInt(age));
    res.redirect('/');
});

router.get('/child/:id', async (req, res) => {
    const child = await db.getChildProfile(req.params.id);
    res.render('profile', { child });
});

router.post('/task/:id/:category', async (req, res) => {
    const { id, category } = req.params;
    const { answer, correct } = req.body;
    const child = await db.getChildProfile(id);
    if (answer.toLowerCase() === correct.toLowerCase()) {
        const points = child.level * 5;
        await db.updateProgress(id, category, points);
    }
    res.redirect(`/child/${id}`);
});

router.get('/task/:id/:category', async (req, res) => {
    const { id, category } = req.params;
    const child = await db.getChildProfile(id);
    const { question, answer } = logic.generateTask(category, child.level);
    res.render('task', { child, category, question, answer });
});

module.exports = router;